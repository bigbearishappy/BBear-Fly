/******************************************************************************
 * @file     main.c
 * @version  V1.00
 * $Revision: 4 $
 * $Date: 13/10/07 3:56p $ 
 * @brief    FMC erase/program/read sample program for MINI51 series MCU
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/   
#include <stdio.h>
#include "Mini51Series.h"
#include "uart.h"
#include "fmc.h"

#define APROM_TEST_BASE             0x3000
#define DATA_FLASH_TEST_BASE        0x3000
#define DATA_FLASH_TEST_END         0x4000
#define TEST_PATTERN 0x12345678


void SYS_Init(void)
{
/*---------------------------------------------------------------------------------------------------------*/
/* Init System Clock                                                                                       */
/*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Enable External XTAL (4~24 MHz) */
    CLK->PWRCON &= ~CLK_PWRCON_XTLCLK_EN_Msk;
    CLK->PWRCON |= (0x1 << CLK_PWRCON_XTLCLK_EN_Pos); // XTAL12M (HXT) Enabled
    
    /* Waiting for 12MHz clock ready */
    while (!(CLK->CLKSTATUS & CLK_CLKSTATUS_XTL_STB_Msk));

    /* Switch HCLK clock source to XTAL */
    CLK->CLKSEL0 &= ~CLK_CLKSEL0_HCLK_S_Msk;
    CLK->CLKSEL0 |= CLK_CLKSEL0_HCLK_S_XTAL;

    /* Enable IP clock */        
    CLK->APBCLK |= CLK_APBCLK_UART_EN_Msk; // UART Clock Enable
    
    /* Select IP clock source */
    CLK->CLKSEL1 &= ~CLK_CLKSEL1_UART_S_Msk;
    CLK->CLKSEL1 |= CLK_CLKSEL1_UART_S_XTAL;// Clock source from external 12 MHz or 32 KHz crystal clock
                      
    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    SystemCoreClockUpdate(); 

/*---------------------------------------------------------------------------------------------------------*/
/* Init I/O Multi-function                                                                                 */
/*---------------------------------------------------------------------------------------------------------*/
    /* Set P0.0,P0.1 multi-function pins for UART RXD and TXD  */
    SYS->P0_MFP = SYS_MFP_P00_TXD | SYS_MFP_P01_RXD;

    /* Lock protected registers */
    SYS_LockReg();
}

void UART_Init()
{
/*---------------------------------------------------------------------------------------------------------*/
/* Init UART                                                                                               */
/*---------------------------------------------------------------------------------------------------------*/
    UART_Open(UART, 115200);
}


static int  set_data_flash_base(uint32_t u32DFBA)
{
    uint32_t   au32Config[2];
    
    if (FMC_ReadConfig(au32Config, 2) < 0)
    {
        printf("\nRead User Config failed!\n");
        return -1;
    }
        
    if ((!(au32Config[0] & 0x1)) && (au32Config[1] == u32DFBA))
        return 0;
        
    FMC_EnableConfigUpdate();
        
    au32Config[0] &= ~0x1;
    au32Config[1] = u32DFBA;

    if (FMC_WriteConfig(au32Config, 2) < 0)
        return -1;
        
    printf("\nSet Data Flash base as 0x%x.\n", DATA_FLASH_TEST_BASE);

    // Perform chip reset to make new User Config take effect
    SYS->IPRSTC1 = SYS_IPRSTC1_CHIP_RST_Msk;
    return 0;
}


int32_t fill_data_pattern(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t u32Pattern)
{
    uint32_t u32Addr;
    
    for (u32Addr = u32StartAddr; u32Addr < u32EndAddr; u32Addr += 4) 
    {
        FMC_Write(u32Addr, u32Pattern);
    }
    return 0;
}


int32_t  verify_data(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t u32Pattern)
{
    uint32_t    u32Addr;
    uint32_t    u32data;
    
    for (u32Addr = u32StartAddr; u32Addr < u32EndAddr; u32Addr += 4) 
    {     
        u32data = FMC_Read(u32Addr);
        if (u32data != u32Pattern)
        { 
           printf("\nFMC_Read data verify failed at address 0x%x, read=0x%x, expect=0x%x\n", u32Addr, u32data, u32Pattern);
           return -1; 
        }         
    }
    return 0;
}


int32_t  flash_test(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t u32Pattern)
{
    uint32_t    u32Addr;
    
    for (u32Addr = u32StartAddr; u32Addr < u32EndAddr; u32Addr += FMC_FLASH_PAGE_SIZE)
    {
        printf("    Flash test address: 0x%x    \r", u32Addr);

        // Erase page
        FMC_Erase(u32Addr);
        
        // Verify if page contents are all 0xFFFFFFFF
        if (verify_data(u32Addr, u32Addr + FMC_FLASH_PAGE_SIZE, 0xFFFFFFFF) < 0)
        {
            printf("\nPage 0x%x erase verify failed!\n", u32Addr);
            return -1;
        }
        
        // Write test pattern to fill the whole page
        if (fill_data_pattern(u32Addr, u32Addr + FMC_FLASH_PAGE_SIZE, u32Pattern) < 0)
        {
            printf("Failed to write page 0x%x!\n", u32Addr);
            return -1;
        }

        // Verify if page contents are all equal to test pattern
        if (verify_data(u32Addr, u32Addr + FMC_FLASH_PAGE_SIZE, u32Pattern) < 0)
        {
            printf("\nData verify failed!\n ");
            return -1;
        }

        FMC_Erase(u32Addr);
        
        // Verify if page contents are all 0xFFFFFFFF
        if (verify_data(u32Addr, u32Addr + FMC_FLASH_PAGE_SIZE, 0xFFFFFFFF) < 0)
        {
            printf("\nPage 0x%x erase verify failed!\n", u32Addr);
            return -1;
        }
				
    } 
				
    printf("\r    Flash Test Passed.          \n");
    return 0;
}

#define DATA_FLAHSH_OFFSET  0x3000

unsigned int temp1;

unsigned char SIM_EEPROM_READ(unsigned int address)
{
unsigned int temp;
  temp=FMC_Read(((address/4)*4)+DATA_FLAHSH_OFFSET);
	return (temp>>((address%4)*8))&0xff;;
}

void SIM_EEPROM_WRITE(unsigned int address,unsigned char data)
{
	unsigned int temp_data;
	unsigned int i,j;
  unsigned int buffer[512/4];	
	
	
	if((SIM_EEPROM_READ(address)==0xff)|((SIM_EEPROM_READ(address)&data)==data))
	{
		temp_data=FMC_Read(((address/4)*4)+DATA_FLAHSH_OFFSET);
		temp_data=~(0x0ff<<((address%4)*8));
		temp_data|=data<<((address%4)*8);
		FMC_Write(((address/4)*4)+DATA_FLAHSH_OFFSET, temp_data);
	}
	else
	     {
				 temp_data=FMC_Read(((address/4)*4)+DATA_FLAHSH_OFFSET);
				 temp_data&=~(0x0ff<<((address%4)*8));
				 temp_data|=data<<((address%4)*8);
				 //backup date
				 j=0;
				 
				// printf("0x%x\n\r",DATA_FLAHSH_OFFSET+(address/512)+(512));
				 for(i=DATA_FLAHSH_OFFSET+((address/512)*512);i<DATA_FLAHSH_OFFSET+((address/512)*512)+512;i=i+4)
				  {
						//printf("0x%x\n\r",i);
						//printf("0x%x\n\r",FMC_Read(i));
					 buffer[j]=FMC_Read(i);
						
						j++;
					}				 
					//erase page
		      FMC_Erase(DATA_FLAHSH_OFFSET+((address/512)*512));
					
					buffer[(address%512)/4]=temp_data;
					j=0;
					for(i=DATA_FLAHSH_OFFSET+((address/512)*512);i<DATA_FLAHSH_OFFSET+((address/512)*512)+512;i=i+4)
				  {
						FMC_Write(i,buffer[j]);
						j++;
					}
		   }
}


int main()
{
    uint32_t    i, u32Data;

    SYS_Init();
    UART_Init();

    printf("\n\n");
    printf("+----------------------------------------+\n");
    printf("|         MINI51 FMC Sample Code         |\n");
    printf("+----------------------------------------+\n");

    SYS_UnlockReg();

    /* Enable FMC ISP function */
    FMC_Open();

    if (set_data_flash_base(DATA_FLASH_TEST_BASE) < 0)
    {
        printf("Failed to set Data Flash base address!\n");
        goto lexit;
    }

    /* Read Data Flash base address */
    u32Data = FMC_ReadDataFlashBaseAddr();
    printf("  Data Flash Base Address ............... [0x%08x]\n", u32Data);
		FMC_Erase(DATA_FLASH_TEST_BASE);		
		
		for(i=0;i<1024;i++)
		{
		SIM_EEPROM_WRITE(i,0);
				if(SIM_EEPROM_READ(i)!=0)
			{
		printf("0x%x",SIM_EEPROM_READ(i));
				while(1);
			}
		}
		for(i=0;i<1024;i++)
	  {
		SIM_EEPROM_WRITE(i,(i&0xff));
			if(SIM_EEPROM_READ(i)!=(i&0xff))
			{
		printf("0x%x",SIM_EEPROM_READ(i));
				while(1);
			}
		}
	#if 0
    printf("\n\nData Flash test =>\n");
    if (flash_test(DATA_FLASH_TEST_BASE, DATA_FLASH_TEST_END, TEST_PATTERN) < 0)
    {
        printf("\n\nUHB test failed!\n");
        goto lexit;
    }
    #endif
lexit:

    /* Disable FMC ISP function */
    FMC_Close();

    /* Lock protected registers */
    SYS_LockReg();
    
    printf("\nFMC Sample Code Completed.\n");
    
    while (1);
}

/*** (C) COPYRIGHT 2013 Nuvoton Technology Corp. ***/
